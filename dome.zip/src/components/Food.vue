<template>
    <div class="hello">
        食品
    </div>
</template>

<script>
export default {
    name: 'Food',
    data () {
        return {
        
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
